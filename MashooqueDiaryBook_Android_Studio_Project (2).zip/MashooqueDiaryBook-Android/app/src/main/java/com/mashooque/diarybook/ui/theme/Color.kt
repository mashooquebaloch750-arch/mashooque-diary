package com.mashooque.diarybook.ui.theme

import androidx.compose.ui.graphics.Color

val RoyalBlue = Color(0xFF2563EB)
val DarkNavy = Color(0xFF172554)
val LightBg = Color(0xFFF1F6FF)
val PureWhite = Color(0xFFFFFFFF)
val AmberAccent = Color(0xFFF59E0B)
val LightBlueCard = Color(0xFFE0EDFF)
