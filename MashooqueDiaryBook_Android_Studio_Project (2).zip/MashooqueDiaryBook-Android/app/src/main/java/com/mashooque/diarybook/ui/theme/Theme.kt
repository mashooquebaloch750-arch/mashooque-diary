package com.mashooque.diarybook.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = RoyalBlue,
    secondary = AmberAccent,
    background = LightBg,
    surface = PureWhite,
    onPrimary = PureWhite,
    onBackground = DarkNavy,
    onSurface = DarkNavy
)

@Composable
fun MashooqueDiaryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        content = content
    )
}
