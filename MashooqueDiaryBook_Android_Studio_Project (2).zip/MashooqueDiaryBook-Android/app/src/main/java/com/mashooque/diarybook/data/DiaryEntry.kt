package com.mashooque.diarybook.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "diary_entries")
data class DiaryEntry(
    @PrimaryKey
    val id: String,
    val title: String,
    val content: String,
    val date: String,
    val time: String,
    val createdAt: Long,
    val updatedAt: Long,
    val mood: String? = null,
    val isFavorite: Boolean = false,
    val tags: String = "", // Comma separated
    val category: String = "Personal"
)
